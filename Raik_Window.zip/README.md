# raik_window
Basic script to show some stats in a floating window

# Commands
* `/ShowRaikWindow` show stats window
* `/HideRaikWindow` hide stat window
* `/RaikReload` reload the stats in case it stuck
* `/RaikFont` font list

